﻿namespace _17_05_17Desarrollo_de_AplicacioneS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnSumaParametroxvalor = new System.Windows.Forms.Button();
            this.btnSumaParametroxReferencia = new System.Windows.Forms.Button();
            this.btnSumaParametxvalorxretorn = new System.Windows.Forms.Button();
            this.btnSumaFormulario = new System.Windows.Forms.Button();
            this.btnSumaConstructor = new System.Windows.Forms.Button();
            this.btnParametroxvalor = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(117, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numero1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(117, 183);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Numero2";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(189, 132);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(118, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(189, 180);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(118, 20);
            this.textBox2.TabIndex = 3;
            // 
            // btnSumaParametroxvalor
            // 
            this.btnSumaParametroxvalor.Location = new System.Drawing.Point(39, 36);
            this.btnSumaParametroxvalor.Name = "btnSumaParametroxvalor";
            this.btnSumaParametroxvalor.Size = new System.Drawing.Size(87, 53);
            this.btnSumaParametroxvalor.TabIndex = 4;
            this.btnSumaParametroxvalor.Text = "Suma (parametro x valor)";
            this.btnSumaParametroxvalor.UseVisualStyleBackColor = true;
            this.btnSumaParametroxvalor.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSumaParametroxReferencia
            // 
            this.btnSumaParametroxReferencia.Location = new System.Drawing.Point(189, 36);
            this.btnSumaParametroxReferencia.Name = "btnSumaParametroxReferencia";
            this.btnSumaParametroxReferencia.Size = new System.Drawing.Size(83, 50);
            this.btnSumaParametroxReferencia.TabIndex = 5;
            this.btnSumaParametroxReferencia.Text = "Suma (parametro x referencia)";
            this.btnSumaParametroxReferencia.UseVisualStyleBackColor = true;
            this.btnSumaParametroxReferencia.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnSumaParametxvalorxretorn
            // 
            this.btnSumaParametxvalorxretorn.Location = new System.Drawing.Point(39, 251);
            this.btnSumaParametxvalorxretorn.Name = "btnSumaParametxvalorxretorn";
            this.btnSumaParametxvalorxretorn.Size = new System.Drawing.Size(92, 63);
            this.btnSumaParametxvalorxretorn.TabIndex = 6;
            this.btnSumaParametxvalorxretorn.Text = "Suma (parametro x valor, con tipo de retorno)";
            this.btnSumaParametxvalorxretorn.UseVisualStyleBackColor = true;
            this.btnSumaParametxvalorxretorn.Click += new System.EventHandler(this.btnSumaParametxvalorxretorn_Click);
            // 
            // btnSumaFormulario
            // 
            this.btnSumaFormulario.Location = new System.Drawing.Point(189, 251);
            this.btnSumaFormulario.Name = "btnSumaFormulario";
            this.btnSumaFormulario.Size = new System.Drawing.Size(83, 63);
            this.btnSumaFormulario.TabIndex = 7;
            this.btnSumaFormulario.Text = "Suma (desde el formulario)";
            this.btnSumaFormulario.UseVisualStyleBackColor = true;
            this.btnSumaFormulario.Click += new System.EventHandler(this.btnSumaFormulario_Click);
            // 
            // btnSumaConstructor
            // 
            this.btnSumaConstructor.Location = new System.Drawing.Point(321, 246);
            this.btnSumaConstructor.Name = "btnSumaConstructor";
            this.btnSumaConstructor.Size = new System.Drawing.Size(89, 68);
            this.btnSumaConstructor.TabIndex = 8;
            this.btnSumaConstructor.Text = "Suma (con constructor con parametro)";
            this.btnSumaConstructor.UseVisualStyleBackColor = true;
            this.btnSumaConstructor.Click += new System.EventHandler(this.btnSumaConstructor_Click);
            // 
            // btnParametroxvalor
            // 
            this.btnParametroxvalor.Location = new System.Drawing.Point(321, 36);
            this.btnParametroxvalor.Name = "btnParametroxvalor";
            this.btnParametroxvalor.Size = new System.Drawing.Size(75, 60);
            this.btnParametroxvalor.TabIndex = 9;
            this.btnParametroxvalor.Text = "Parametro x valor";
            this.btnParametroxvalor.UseVisualStyleBackColor = true;
            this.btnParametroxvalor.Click += new System.EventHandler(this.btnParametroxvalor_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(739, 314);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 74);
            this.btnSalir.TabIndex = 10;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 400);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnParametroxvalor);
            this.Controls.Add(this.btnSumaConstructor);
            this.Controls.Add(this.btnSumaFormulario);
            this.Controls.Add(this.btnSumaParametxvalorxretorn);
            this.Controls.Add(this.btnSumaParametroxReferencia);
            this.Controls.Add(this.btnSumaParametroxvalor);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnSumaParametroxvalor;
        private System.Windows.Forms.Button btnSumaParametroxReferencia;
        private System.Windows.Forms.Button btnSumaParametxvalorxretorn;
        private System.Windows.Forms.Button btnSumaFormulario;
        private System.Windows.Forms.Button btnSumaConstructor;
        private System.Windows.Forms.Button btnParametroxvalor;
        private System.Windows.Forms.Button btnSalir;
    }
}

