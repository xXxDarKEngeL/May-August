﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _17_05_17Desarrollo_de_AplicacioneS
{
    public partial class Form1 : Form
    {
        Practica1 s1 = new Practica1();
        Practica1 s2 = new Practica1(9, 10);
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            s1.suma(Convert.ToInt32(textBox1.Text),Convert.ToInt32(textBox2.Text));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int x = 7;
            int y = 9;
            int resultado = 0;
            s1.sumaxreferencia(ref x, ref y, ref resultado);
            MessageBox.Show(Convert.ToString(x));
            MessageBox.Show(Convert.ToString(y));
            MessageBox.Show("el resultado es: " + Convert.ToString(resultado));
        }

        private void btnParametroxvalor_Click(object sender, EventArgs e)
        {
            int x = 100;
            int y = 10;
            int resultado = 0;
            s1.parametroxvalor(x, y, resultado);
            MessageBox.Show("el resultado es: "+resultado.ToString());
            MessageBox.Show(x.ToString());
            MessageBox.Show(y.ToString());
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSumaParametxvalorxretorn_Click(object sender, EventArgs e)
        {
            int resultado = 0;
            resultado=s1.parametroxvalorxretorno(Convert.ToInt32(textBox1.Text),Convert.ToInt32(textBox2.Text));
            MessageBox.Show("el resultado es: "+resultado.ToString());
        }

        private void btnSumaFormulario_Click(object sender, EventArgs e)
        {
            int x1, x2, resultado = 0;
            x1 = Convert.ToInt32(textBox1.Text);
            x2 = Convert.ToInt32(textBox2.Text);
            resultado = x1 + x2;
            MessageBox.Show("El resultado es: "+resultado);
        }

        private void btnSumaConstructor_Click(object sender, EventArgs e)
        {
            s2.SumaConstructor();
        }
    }
}
