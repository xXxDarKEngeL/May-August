﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _17_05_17Desarrollo_de_AplicacioneS
{
    class Practica1
    {
        public Practica1() { }
        public Practica1(int x, int y)
        {
            this.x1 = x;
            this.y2 = y;
        }
        int x1, y2;
        public void suma(int numero1, int numero2)
        {
            int resultado = 0;
            resultado = numero1 + numero2;
            MessageBox.Show("El resultado es: "+ resultado);
        }
        public void sumaxreferencia(ref int xx, ref int yy, ref int resultado)
        {
            resultado = xx + yy;
            xx = 20;
            yy = 30;
        }
        public void parametroxvalor(int x, int y, int resultado)
        {
            resultado = x + y;
            x = 20;
            y = 30;
            MessageBox.Show(resultado.ToString());
        }
        public int parametroxvalorxretorno(int x, int y)
        {
            int resultado = 0;
            resultado = x + y;
            return resultado;
        }
        public void SumaConstructor()
        {
            int resultado = 0;
            resultado = x1 + y2;
            MessageBox.Show("El resultado es: " + resultado);
        }
    }
}
