﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _26_05_17OrdendecompraS
{
    public partial class Form1 : Form
    {
        Cliente bd = new Cliente();
        OrdenCompra bd1 = new OrdenCompra();
        Producto bd2 = new Producto();
        Contiene bd3 = new Contiene();
        string mensaje = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            bd.BD = "CompraS";
            bd.ServidorSQL="PC11";
            bd1.BD = "CompraS";
            bd1.ServidorSQL = "PC11";
            bd2.BD = "CompraS";
            bd2.ServidorSQL = "PC11";
            bd3.BD = "CompraS";
            bd3.ServidorSQL = "PC11";
            txtBxMensaje.Text = mensaje;
        }

        private void btnAltasCliente_Click(object sender, EventArgs e)
        {
            bd.AltaCliente(ref mensaje, Convert.ToInt32(txtBxClaveCliente1.Text), txtBxNombreCliente.Text, txtBxDireccionCliente.Text, txtBxCPostalCliente.Text);
            txtBxMensaje.Text=mensaje ;
            bd.consultaclientecmbbox(ref mensaje, comboBoxClaveClienteOrden);
        }

        private void btnConsulGenerCliente_Click(object sender, EventArgs e)
        {
            bd.Consultar_Cliente(ref mensaje, ltBxClientes);
            
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnAltasProducto_Click(object sender, EventArgs e)
        {
            bd2.AltaProducto(ref mensaje, Convert.ToInt32(txtBxClaveProducto.Text),txtBxNombreProducto.Text, Convert.ToSingle(txtBxPrecioProducto.Text));
            txtBxMensaje.Text = mensaje;
            bd2.consultaprodcutcmbbox(ref mensaje, comboBoxClaveProductOrden);
        }

        private void btnComprobarConexion_Click(object sender, EventArgs e)
        {
            bd.Conectar(ref mensaje);
            txtBxMensaje.Text = mensaje;
        }

        private void btnAltasOrden_Click(object sender, EventArgs e)
        {
            if (comboBoxClaveProductOrden.Text == "" && comboBoxClaveOrden1.Text == "" && txtBxCantidadOrden.Text == "" && txtBxTotalOrden.Text == "")
            {
                bd3.AltaContiene(ref mensaje, Convert.ToInt32(comboBoxClaveProductOrden.Text), Convert.ToInt32(comboBoxClaveOrden1.Text), Convert.ToInt32(txtBxCantidadOrden.Text), Convert.ToSingle(txtBxTotalOrden.Text));
            }
            else
            {
                mensaje = "No es posible insertar, Datos insuficientes";
            }
            if (txtBxClaveOrden.Text != "" && txtBxFechEmisionOrden.Text != "" && txtBxFechEntregaOrden.Text != "" && comboBoxClaveClienteOrden.Text != "")
            {
                bd1.AltaOrdenCompra(ref mensaje, Convert.ToInt32(txtBxClaveOrden.Text), txtBxFechEmisionOrden.Text, txtBxFechEntregaOrden.Text, Convert.ToInt32(comboBoxClaveClienteOrden.Text));
            }
            else
            {
                mensaje = "No es posible insertar, Datos insuficientes";
            }
            txtBxMensaje.Text = mensaje;
        }

        private void btnConsulGenerOrden_Click(object sender, EventArgs e)
        {
            bd1.Consultar_OrdenCompra(ref mensaje, ltBxOrden);
            bd3.Consultar_Contiene(ref mensaje, ltBxOrden);

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void btnBajasProducto_Click(object sender, EventArgs e)
        {

        }

        private void btnConsulGenerProducto_Click(object sender, EventArgs e)
        {
            bd2.Consultar_Producto(ref mensaje, ltBxProducto);
        }

        private void txtBxClaveOrden_TextChanged(object sender, EventArgs e)
        {
            comboBoxClaveOrden1.Text = txtBxClaveOrden.Text;
        }

        private void comboBoxClaveOrden1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
