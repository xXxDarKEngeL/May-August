﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _26_05_17OrdendecompraS
{
    class Cliente
    {
        public string ServidorSQL { set; get; }
        public string BD { set; get; }

        public SqlConnection Conectar(ref string mensaje)
        {
            SqlConnection carretera = new SqlConnection();
            carretera.ConnectionString = "data source = " + ServidorSQL + " ; Initial Catalog=" + BD + " ; Integrated Security=true;";
            try
            {
                carretera.Open();
                mensaje = "Conexion Abierta";
            }
            catch (Exception t)
            {
                carretera = null;
                mensaje = "ERROR: " + t.Message;
            }
            return carretera;
        }

        public void AltaCliente(ref string messaje, int ClaveClient, string Nombre, string Direccion, string CodigoP)
        {
            SqlConnection carretera = new SqlConnection();
            carretera.ConnectionString = @"data source = " + ServidorSQL + " ; Initial Catalog=" + BD + " ; Integrated Security=true;";
            SqlCommand carrier = new SqlCommand();
            try
            {
                carretera.Open();
                carrier.CommandText = "insert into Cliente (idcliente, nombre, direccion, cp) values ('" + ClaveClient + "','" + Nombre + "','" + Direccion + "','" + CodigoP + "')";
                carrier.Connection = carretera;
                carrier.ExecuteNonQuery();
                messaje="Cliente Creado";
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                messaje="ERROR: " + t.Message;
            }
        }

        public void Consultar_Cliente(ref string mensaje, ListBox lista)
        {
            SqlConnection carretera = new SqlConnection(@"data source= " + ServidorSQL + " ; Initial Catalog= " + BD + " ; Integrated Security=true;");
            SqlCommand carrito = new SqlCommand();
            SqlDataReader contenedor;
            lista.Items.Clear();
            try
            {
                carretera.Open();
                carrito.CommandText = "select * from Cliente";
                carrito.Connection = carretera;
                contenedor = carrito.ExecuteReader();
                while (contenedor.Read())
                {
                    lista.Items.Add((contenedor[0].ToString() + "," + contenedor[1].ToString() + "," + contenedor[2].ToString() + "," + contenedor[3].ToString()));
                }
                MessageBox.Show("Consulta finalizada");
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                MessageBox.Show("ERROR: " + t.Message);
            }
        }
        public void consultaclientecmbbox(ref string mensajee, ComboBox cmbbox)
        {
            SqlConnection carretera = new SqlConnection(@"data source= " + ServidorSQL + " ; Initial Catalog= " + BD + " ; Integrated Security=true;");
            SqlCommand carrito = new SqlCommand();
            SqlDataReader contenedor;
            cmbbox.Items.Clear();
            try
            {
                carretera.Open();
                carrito.CommandText = "select * from Cliente";

                carrito.Connection = carretera;
                contenedor = carrito.ExecuteReader();
                while (contenedor.Read())
                {
                    cmbbox.Items.Add(contenedor[0].ToString());
                }
                mensajee = "Consulta finalizada";
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                mensajee = "ERROR: " + t.Message;
            }
        }
        public void ConsultaOperacion(ref string mensaje, int clave, ref double preci)
        {

        }
    }
    class OrdenCompra : Cliente
    {
        public void AltaOrdenCompra(ref string messaje, int idorden, string fechaemsion, string fechaentrega, int idClientee)
        {
            SqlConnection carretera = new SqlConnection();
            carretera.ConnectionString = @"data source = " + ServidorSQL + " ; Initial Catalog=" + BD + " ; Integrated Security=true;";
            SqlCommand carrier = new SqlCommand();
            try
            {
                carretera.Open();
                carrier.CommandText = "insert into OrdendeCompra (idOrden, fechaemision, fechaentrega, idCliente) values ('" + idorden + "','" + fechaemsion + "','" + fechaentrega + "','" + idClientee + "')";
                carrier.Connection = carretera;
                carrier.ExecuteNonQuery();
               messaje="Orden de Compra Creada";
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                messaje="ERROR: " + t.Message;
            }
        }
        public void Consultar_OrdenCompra(ref string mensaje, ListBox lista)
        {
            SqlConnection carretera = new SqlConnection(@"data source= " + ServidorSQL + " ; Initial Catalog= " + BD + " ; Integrated Security=true;");
            SqlCommand carrito = new SqlCommand();
            SqlDataReader contenedor;
            lista.Items.Clear();
            try
            {
                carretera.Open();
                carrito.CommandText = "select * from OrdendeCompra";

                carrito.Connection = carretera;
                contenedor = carrito.ExecuteReader();
                while (contenedor.Read())
                {
                    lista.Items.Add((contenedor[0].ToString() + "," + contenedor[1].ToString() + "," + contenedor[2].ToString() + "," + contenedor[3].ToString()));
                }
                mensaje="Consulta finalizada";
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                mensaje="ERROR: " + t.Message;
            }
        }
    }
    class Producto : Cliente
    {
        public void AltaProducto(ref string mensaje, int idProducto, string Nombre, float Precio)
        {
            SqlConnection carretera = new SqlConnection();
            carretera.ConnectionString = @"data source = " + ServidorSQL + " ; Initial Catalog=" + BD + " ; Integrated Security=true;";
            SqlCommand carrier = new SqlCommand();
            try
            {
                carretera.Open();
                carrier.CommandText = "insert into Producto (idProducto, Descripcion, Precio) values ('" + idProducto + "','" + Nombre + "','" + Precio + "')";
                carrier.Connection = carretera;
                carrier.ExecuteNonQuery();
                mensaje="Producto Añadido";
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                mensaje="ERROR: " + t.Message;
            }
        }
        public void Consultar_Producto(ref string mensaje, ListBox lista)
        {
            SqlConnection carretera = new SqlConnection(@"data source= " + ServidorSQL + " ; Initial Catalog= " + BD + " ; Integrated Security=true;");
            SqlCommand carrito = new SqlCommand();
            SqlDataReader contenedor;
            lista.Items.Clear();
            try
            {
                carretera.Open();
                carrito.CommandText = "select * from Producto";
                carrito.Connection = carretera;
                contenedor = carrito.ExecuteReader();
                while (contenedor.Read())
                {
                    lista.Items.Add((contenedor[0].ToString() + "," + contenedor[1].ToString() + "," + contenedor[2].ToString()));
                }
                MessageBox.Show("Consulta finalizada");
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                MessageBox.Show("ERROR: " + t.Message);
            }
        }
        public void consultaprodcutcmbbox(ref string mensajee, ComboBox cmbbox)
        {
            SqlConnection carretera = new SqlConnection(@"data source= " + ServidorSQL + " ; Initial Catalog= " + BD + " ; Integrated Security=true;");
            SqlCommand carrito = new SqlCommand();
            SqlDataReader contenedor;
            cmbbox.Items.Clear();
            try
            {
                carretera.Open();
                carrito.CommandText = "select * from Producto";

                carrito.Connection = carretera;
                contenedor = carrito.ExecuteReader();
                while (contenedor.Read())
                {
                    cmbbox.Items.Add(contenedor[0].ToString());
                }
                mensajee = "Consulta finalizada";
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                mensajee = "ERROR: " + t.Message;
            }
        }
    }
    class Contiene : Cliente
    {
        public void AltaContiene(ref string messaje, int idOrdenn, int idProductoo, int Cantidad, float Total)
        {
            SqlConnection carretera = new SqlConnection();
            carretera.ConnectionString = @"data source = " + ServidorSQL + " ; Initial Catalog=" + BD + " ; Integrated Security=true;";
            SqlCommand carrier = new SqlCommand();
            try
            {
                carretera.Open();
                carrier.CommandText = "insert into Contiene (idOrden, idProducto, Cantidad, Total) values ('" + idOrdenn + "','" + idProductoo + "','" + Cantidad + "','" + Total + "')";
                carrier.Connection = carretera;
                carrier.ExecuteNonQuery();
                MessageBox.Show("Contencion Creada");
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                MessageBox.Show("ERROR: " + t.Message);
            }
        }
        public void Consultar_Contiene(ref string mensaje, ListBox lista)
        {
            SqlConnection carretera = new SqlConnection(@"data source= " + ServidorSQL + " ; Initial Catalog= " + BD + " ; Integrated Security=true;");
            SqlCommand carrito = new SqlCommand();
            SqlDataReader contenedor;

            try
            {
                carretera.Open();
                carrito.CommandText = "select * from Contiene";
                carrito.Connection = carretera;
                contenedor = carrito.ExecuteReader();
                while (contenedor.Read())
                {
                    lista.Items.Add((contenedor[0].ToString() + "," + contenedor[1].ToString() + "," + contenedor[2].ToString() + "," + contenedor[3].ToString()));
                }
                MessageBox.Show("Consulta finalizada");
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                MessageBox.Show("ERROR: " + t.Message);
            }
        }
    }
}
