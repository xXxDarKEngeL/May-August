﻿namespace _19_05_17PruebaSQLServer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBx1 = new System.Windows.Forms.TextBox();
            this.ltBx1 = new System.Windows.Forms.ListBox();
            this.btnPrimeraForma = new System.Windows.Forms.Button();
            this.btnSegundaForma = new System.Windows.Forms.Button();
            this.btnTerceraForma = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBxIDProduct = new System.Windows.Forms.TextBox();
            this.txtBxPrecio = new System.Windows.Forms.TextBox();
            this.txtBxCantidad = new System.Windows.Forms.TextBox();
            this.cmbBxNombre = new System.Windows.Forms.ComboBox();
            this.btnInsertar = new System.Windows.Forms.Button();
            this.ltBx2 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txtBx1
            // 
            this.txtBx1.BackColor = System.Drawing.SystemColors.MenuText;
            this.txtBx1.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBx1.ForeColor = System.Drawing.Color.Red;
            this.txtBx1.Location = new System.Drawing.Point(12, 103);
            this.txtBx1.Name = "txtBx1";
            this.txtBx1.Size = new System.Drawing.Size(301, 25);
            this.txtBx1.TabIndex = 0;
            this.txtBx1.TextChanged += new System.EventHandler(this.txtBx1_TextChanged);
            // 
            // ltBx1
            // 
            this.ltBx1.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ltBx1.Font = new System.Drawing.Font("Showcard Gothic", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltBx1.ForeColor = System.Drawing.Color.Chartreuse;
            this.ltBx1.FormattingEnabled = true;
            this.ltBx1.ItemHeight = 27;
            this.ltBx1.Location = new System.Drawing.Point(12, 12);
            this.ltBx1.Name = "ltBx1";
            this.ltBx1.Size = new System.Drawing.Size(301, 85);
            this.ltBx1.TabIndex = 1;
            // 
            // btnPrimeraForma
            // 
            this.btnPrimeraForma.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrimeraForma.Location = new System.Drawing.Point(12, 153);
            this.btnPrimeraForma.Name = "btnPrimeraForma";
            this.btnPrimeraForma.Size = new System.Drawing.Size(178, 66);
            this.btnPrimeraForma.TabIndex = 2;
            this.btnPrimeraForma.Text = "Primera Forma de Conectar";
            this.btnPrimeraForma.UseVisualStyleBackColor = true;
            this.btnPrimeraForma.Click += new System.EventHandler(this.btnPrimeraForma_Click);
            // 
            // btnSegundaForma
            // 
            this.btnSegundaForma.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSegundaForma.Location = new System.Drawing.Point(666, 153);
            this.btnSegundaForma.Name = "btnSegundaForma";
            this.btnSegundaForma.Size = new System.Drawing.Size(157, 66);
            this.btnSegundaForma.TabIndex = 3;
            this.btnSegundaForma.Text = "Segunda Forma de Conectar";
            this.btnSegundaForma.UseVisualStyleBackColor = true;
            this.btnSegundaForma.Click += new System.EventHandler(this.btnSegunda_Click);
            // 
            // btnTerceraForma
            // 
            this.btnTerceraForma.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTerceraForma.Location = new System.Drawing.Point(12, 254);
            this.btnTerceraForma.Name = "btnTerceraForma";
            this.btnTerceraForma.Size = new System.Drawing.Size(178, 66);
            this.btnTerceraForma.TabIndex = 4;
            this.btnTerceraForma.Text = "Tercera Forma de  Conectar";
            this.btnTerceraForma.UseVisualStyleBackColor = true;
            this.btnTerceraForma.Click += new System.EventHandler(this.btnTerceraForma_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Lime;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(346, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "ID Producto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Lime;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(346, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 18);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nombre";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Lime;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(346, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 18);
            this.label3.TabIndex = 8;
            this.label3.Text = "Precio";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Lime;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(346, 142);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Cantidad";
            // 
            // txtBxIDProduct
            // 
            this.txtBxIDProduct.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBxIDProduct.ForeColor = System.Drawing.Color.Lime;
            this.txtBxIDProduct.Location = new System.Drawing.Point(452, 48);
            this.txtBxIDProduct.Name = "txtBxIDProduct";
            this.txtBxIDProduct.Size = new System.Drawing.Size(165, 25);
            this.txtBxIDProduct.TabIndex = 10;
            // 
            // txtBxPrecio
            // 
            this.txtBxPrecio.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBxPrecio.ForeColor = System.Drawing.Color.Lime;
            this.txtBxPrecio.Location = new System.Drawing.Point(452, 111);
            this.txtBxPrecio.Name = "txtBxPrecio";
            this.txtBxPrecio.Size = new System.Drawing.Size(165, 25);
            this.txtBxPrecio.TabIndex = 11;
            this.txtBxPrecio.TextChanged += new System.EventHandler(this.txtBxPrecio_TextChanged);
            // 
            // txtBxCantidad
            // 
            this.txtBxCantidad.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBxCantidad.ForeColor = System.Drawing.Color.Lime;
            this.txtBxCantidad.Location = new System.Drawing.Point(452, 142);
            this.txtBxCantidad.Name = "txtBxCantidad";
            this.txtBxCantidad.Size = new System.Drawing.Size(165, 25);
            this.txtBxCantidad.TabIndex = 12;
            // 
            // cmbBxNombre
            // 
            this.cmbBxNombre.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBxNombre.ForeColor = System.Drawing.Color.Lime;
            this.cmbBxNombre.FormattingEnabled = true;
            this.cmbBxNombre.Items.AddRange(new object[] {
            "Laptop",
            "Computadora",
            "Celular",
            "Tablet",
            "Impresora",
            "Scanner"});
            this.cmbBxNombre.Location = new System.Drawing.Point(452, 79);
            this.cmbBxNombre.Name = "cmbBxNombre";
            this.cmbBxNombre.Size = new System.Drawing.Size(165, 26);
            this.cmbBxNombre.TabIndex = 13;
            // 
            // btnInsertar
            // 
            this.btnInsertar.Font = new System.Drawing.Font("Pristina", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsertar.Location = new System.Drawing.Point(666, 82);
            this.btnInsertar.Name = "btnInsertar";
            this.btnInsertar.Size = new System.Drawing.Size(157, 53);
            this.btnInsertar.TabIndex = 14;
            this.btnInsertar.Text = "Insertar";
            this.btnInsertar.UseVisualStyleBackColor = true;
            this.btnInsertar.Click += new System.EventHandler(this.btnInsertar_Click);
            // 
            // ltBx2
            // 
            this.ltBx2.BackColor = System.Drawing.Color.Bisque;
            this.ltBx2.Font = new System.Drawing.Font("Pristina", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltBx2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ltBx2.FormattingEnabled = true;
            this.ltBx2.ItemHeight = 27;
            this.ltBx2.Location = new System.Drawing.Point(361, 189);
            this.ltBx2.Name = "ltBx2";
            this.ltBx2.Size = new System.Drawing.Size(240, 112);
            this.ltBx2.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(893, 490);
            this.Controls.Add(this.ltBx2);
            this.Controls.Add(this.btnInsertar);
            this.Controls.Add(this.cmbBxNombre);
            this.Controls.Add(this.txtBxCantidad);
            this.Controls.Add(this.txtBxPrecio);
            this.Controls.Add(this.txtBxIDProduct);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnTerceraForma);
            this.Controls.Add(this.btnSegundaForma);
            this.Controls.Add(this.btnPrimeraForma);
            this.Controls.Add(this.ltBx1);
            this.Controls.Add(this.txtBx1);
            this.ForeColor = System.Drawing.Color.SteelBlue;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBx1;
        private System.Windows.Forms.ListBox ltBx1;
        private System.Windows.Forms.Button btnPrimeraForma;
        private System.Windows.Forms.Button btnSegundaForma;
        private System.Windows.Forms.Button btnTerceraForma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBxIDProduct;
        private System.Windows.Forms.TextBox txtBxPrecio;
        private System.Windows.Forms.TextBox txtBxCantidad;
        private System.Windows.Forms.ComboBox cmbBxNombre;
        private System.Windows.Forms.Button btnInsertar;
        private System.Windows.Forms.ListBox ltBx2;
    }
}

