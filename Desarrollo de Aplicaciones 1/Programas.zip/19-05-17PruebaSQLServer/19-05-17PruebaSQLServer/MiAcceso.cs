﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _19_05_17PruebaSQLServer
{
    class MiAcceso
    {
        public string ServidorSQL { set; get; }
        public string BD { set; get; }

        public SqlConnection Conectar(ref string mensaje)
        {
            SqlConnection carretera = new SqlConnection();
            carretera.ConnectionString = "data source = " + ServidorSQL + " ; Initial Catalog=" + BD + " ; Integrated Security=true;";
            try
            {
                carretera.Open();
                mensaje = "Conexion Abierta";
            }
            catch (Exception t)
            {
                carretera = null;
                mensaje = "ERROR: "+t.Message;
            }
            return carretera;
        }
        public void Conectar2()
        {
            SqlConnection carretera = new SqlConnection(@"data source=PC01 " + " ;Initial Catalog=22-05-17_Prueba " + " ;Integrated Security=true;");
            
            try
            {
                carretera.Open();
                MessageBox.Show("Conexion Abierta");
            }
            catch (Exception t)
            {
                carretera = null;
                MessageBox.Show("ERROR: " + t.Message);
            }
        }
        public void Conectar3()
        {
            SqlConnection carretera = new SqlConnection();
            carretera.ConnectionString = @"data source=PC24\MSSQLSERVER2016 " + " ;Initial Catalog=ServidorSQL " + " ;Integrated Security=true;";
            try
            {
                carretera.Open();
                MessageBox.Show("Conexion Abierta");
            }
            catch (Exception t)
            {
                carretera = null;
                MessageBox.Show("ERROR: " + t.Message);
            }
        }
        public void Insertar(ref string Mensaje, string VarNombre, float VarPrecio, int VarCantidad)
        {
           // SqlConnection carretera = new SqlConnection();
            SqlConnection carretera = new SqlConnection(@"data source=PC01 " + " ;Initial Catalog=22-05-17_Prueba " + " ;Integrated Security=true;");
            SqlCommand carrito = new SqlCommand();
            try
            {
                carretera.Open();
                carrito.CommandText = "insert into Producto (Nombre, Precio, Cantidad) values ('" + VarNombre + "', '" + VarPrecio + "', '" + VarCantidad + "')";
                carrito.Connection = carretera;
                carrito.ExecuteNonQuery();
                MessageBox.Show("Producto Insertado");
                carretera.Close();
            }
            catch (Exception t)
            {
                carretera = null;
                MessageBox.Show("ERROR: " + t.Message);
            }
        }
    }
}
