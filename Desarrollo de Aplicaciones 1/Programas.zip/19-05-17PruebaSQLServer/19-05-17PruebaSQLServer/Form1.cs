﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _19_05_17PruebaSQLServer
{
    public partial class Form1 : Form
    {
        MiAcceso obj = new MiAcceso();
        public Form1()
        {
            InitializeComponent();
        }

        private void txtBx1_TextChanged(object sender, EventArgs e)
        {
            //string mensaje = "";
            //obj.ServidorSQL= @"PC24\MSSQLSERVER2016";
            //obj.BD = "ServidorSQL";
            //obj.Conectar(ref mensaje);
            //txtBx1.Text = mensaje;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string mensaje = "";
            obj.ServidorSQL = @"PC01";
            obj.BD = "22-05-17_Prueba";
            obj.Conectar(ref mensaje);
            txtBx1.Text = mensaje;
            ltBx1.Items.Add(mensaje);
        }

        private void btnPrimeraForma_Click(object sender, EventArgs e)
        {
            string mensaje = "";
            obj.ServidorSQL = @"PC01";
            obj.BD = "22-05-17_Prueba";
            obj.Conectar(ref mensaje);
            txtBx1.Text = mensaje;
            ltBx1.Items.Add(mensaje);
        }

        private void btnSegunda_Click(object sender, EventArgs e)
        {
            obj.Conectar2();
        }

        private void btnTerceraForma_Click(object sender, EventArgs e)
        {
            obj.Conectar3();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtBxPrecio_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            string mensajee = "";
            obj.Insertar(ref mensajee,cmbBxNombre.Text,Convert.ToSingle(txtBxPrecio.Text),Convert.ToInt32(txtBxCantidad.Text));
            ltBx2.Items.Add(mensajee);
        }
    }
}
