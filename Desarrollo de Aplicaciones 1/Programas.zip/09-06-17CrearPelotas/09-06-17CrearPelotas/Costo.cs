﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _09_06_17CrearPelotas
{
    class Costo
    {
        public void Calcular_Costo1(int diametro, string material,int cantidad, ref double total)
        {
            if (diametro == 7 && material == "goma")
            {
                total = 8 * cantidad;
            }
            else if (diametro == 7 && material == "plastico")
            {
                total = 10 * cantidad;
            }
            else if (diametro == 7 && material == "piel")
            {
                total = 50 * cantidad;
            }
            if (diametro == 9 && material == "goma")
            {
                total = 16 * cantidad;
            }
            else if (diametro == 9 && material == "plastico")
            {
                total = 20 * cantidad;
            }
            else if (diametro == 9 && material == "piel")
            {
                total = 100 * cantidad;
            }
            if (diametro == 12 && material == "goma")
            {
                total = 32 * cantidad;
            }
            else if (diametro == 12 && material == "plastico")
            {
                total = 40 * cantidad;
            }
            else if (diametro == 12 && material == "piel")
            {
                total = 200 * cantidad;
            }
        }
        public void Imprimir_Arreglo(ListBox lista)
        {

        }
    }
    class Checkabox : Costo
    {
        double totale1 = 0, totale2 = 0;
        public void Calcular_check1(int diamet, double colore, int materiale,int cantidade, ref double totale)
        { 
            
            diamet = 10;
            colore = 1.9;
            materiale = 6;
            totale1 = (diamet + colore + materiale) * cantidade;
            if (cantidade>100)
            {
                totale2 = totale1 * .05;
                
            }
            else if (cantidade > 500)
            {
                totale2 = totale1 * .15;
                
            }
            else if (cantidade > 1000)
            {
                totale2 = totale1 * .25;
                
            }
            totale = totale1 - totale2;
         }
        public void Calcular_check2(int diamet, double colore, int materiale, int cantidade, ref double totale)
        {
            //double totale1 = 0, totale2 = 0;
            diamet = 10;
            colore = 1.5;
            materiale = 6;
            totale1 = (diamet + colore + materiale) * cantidade;
            if (cantidade > 100)
            {
                totale2 = totale1 * .05;

            }
            else if (cantidade > 500)
            {
                totale2 = totale1 * .15;

            }
            else if (cantidade > 1000)
            {
                totale2 = totale1 * .25;

            }
            totale = totale1 - totale2;
        }
        public void Calcular_check3(int diamet, double colore, int materiale, int cantidade, ref double totale)
        {
            //double totale1 = 0, totale2 = 0;
            diamet = 10;
            colore = 1.9;
            materiale = 6;
            totale1 = (diamet + colore + materiale) * cantidade;
            if (cantidade > 100)
            {
                totale2 = totale1 * .05;

            }
            else if (cantidade > 500)
            {
                totale2 = totale1 * .15;

            }
            else if (cantidade > 1000)
            {
                totale2 = totale1 * .25;

            }
            totale = totale1 - totale2;
        }
        public void Calcular_check4(int diamet, double colore, int materiale, int cantidade, ref double totale)
        {
            //double totale1 = 0, totale2 = 0;
            diamet = 10;
            colore = 1.5;
            materiale = 12;
            totale1 = (diamet + colore + materiale) * cantidade;
            if (cantidade > 100)
            {
                totale2 = totale1 * .05;

            }
            else if (cantidade > 500)
            {
                totale2 = totale1 * .15;

            }
            else if (cantidade > 1000)
            {
                totale2 = totale1 * .25;

            }
            totale = totale1 - totale2;
        }
        public void Calcular_check5(int diamet, double colore, int materiale, int cantidade, ref double totale)
        {
            //double totale1 = 0, totale2 = 0;
            diamet = 10;
            colore = 1.9;
            materiale = 12;
            totale1 = (diamet + colore + materiale) * cantidade;
            if (cantidade > 100)
            {
                totale2 = totale1 * .05;

            }
            else if (cantidade > 500)
            {
                totale2 = totale1 * .15;

            }
            else if (cantidade > 1000)
            {
                totale2 = totale1 * .25;

            }
            totale = totale1 - totale2;
        }
        public void Calcular_check6(int diamet, double colore, int materiale, int cantidade, ref double totale)
        {
            //double totale1 = 0, totale2 = 0;
            diamet = 10;
            colore = 1.5;
            materiale = 12;
            totale1 = (diamet + colore + materiale) * cantidade;
            if (cantidade > 100)
            {
                totale2 = totale1 * .05;

            }
            else if (cantidade > 500)
            {
                totale2 = totale1 * .15;

            }
            else if (cantidade > 1000)
            {
                totale2 = totale1 * .25;

            }
            totale1 = totale1 - totale2;
        }
        public void Calcular_check7(int diamet, double colore, int materiale, int cantidade, ref double totale)
        {
            //double totale1 = 0, totale2 = 0;
            diamet = 10;
            colore = 1.9;
            materiale = 16;
            totale1 = (diamet + colore + materiale) * cantidade;
            if (cantidade > 100)
            {
                totale2 = totale1 * .05;

            }
            else if (cantidade > 500)
            {
                totale2 = totale1 * .15;

            }
            else if (cantidade > 1000)
            {
                totale2 = totale1 * .25;

            }
            totale = totale1 - totale2;
        }
        public void Calcular_check8(int diamet, double colore, int materiale, int cantidade, ref double totale)
        {
            //double totale1 = 0, totale2 = 0;
            diamet = 10;
            colore = 1.5;
            materiale = 16;
            totale1 = (diamet + colore + materiale) * cantidade;
            if (cantidade > 100)
            {
                totale2 = totale1 * .05;

            }
            else if (cantidade > 500)
            {
                totale2 = totale1 * .15;

            }
            else if (cantidade > 1000)
            {
                totale2 = totale1 * .25;

            }
            totale = totale1 - totale2;
        }
        public void Calcular_check9(int diamet, double colore, int materiale, int cantidade, ref double totale)
        {
            //double totale1 = 0, totale2 = 0;
            diamet = 10;
            colore = 1.9;
            materiale = 16;
            totale1 = (diamet + colore + materiale) * cantidade;
            if (cantidade > 100)
            {
                totale2 = totale1 * .05;

            }
            else if (cantidade > 500)
            {
                totale2 = totale1 * .15;

            }
            else if (cantidade > 1000)
            {
                totale2 = totale1 * .25;

            }
            totale = totale1 - totale2;
        }
    }
}
