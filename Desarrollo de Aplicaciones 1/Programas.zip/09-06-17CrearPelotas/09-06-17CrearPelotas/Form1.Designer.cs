﻿namespace _09_06_17CrearPelotas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ltBxArre1 = new System.Windows.Forms.ListBox();
            this.btnImprimirArre1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBxCantidad1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lblTotal1 = new System.Windows.Forms.Label();
            this.btnCalcularCosto1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBxMaterial = new System.Windows.Forms.TextBox();
            this.txtBxColor = new System.Windows.Forms.TextBox();
            this.txtBxDiametro = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbBxCantidad = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblTotal2 = new System.Windows.Forms.Label();
            this.btnCalcularCosto2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbBxMaterial = new System.Windows.Forms.ComboBox();
            this.cmbBxColor = new System.Windows.Forms.ComboBox();
            this.cmbBxDiametro = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.btnCalcularCosto3 = new System.Windows.Forms.Button();
            this.lblTotal3 = new System.Windows.Forms.Label();
            this.radioBtnPlastico = new System.Windows.Forms.RadioButton();
            this.radioBtnGoma = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.radioBtnLila = new System.Windows.Forms.RadioButton();
            this.radioBtnBlanco = new System.Windows.Forms.RadioButton();
            this.radioBtnAmarillo = new System.Windows.Forms.RadioButton();
            this.radioBtn3 = new System.Windows.Forms.RadioButton();
            this.radioBtn2 = new System.Windows.Forms.RadioButton();
            this.radioBtn1 = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnArreCheck = new System.Windows.Forms.Button();
            this.litBxArreCheck = new System.Windows.Forms.ListBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnCostoCheckbox = new System.Windows.Forms.Button();
            this.checkBoxPiel = new System.Windows.Forms.CheckBox();
            this.checkBoxGoma = new System.Windows.Forms.CheckBox();
            this.checkBoxPlastico = new System.Windows.Forms.CheckBox();
            this.checkBoxRojo = new System.Windows.Forms.CheckBox();
            this.checkBoxVioleta = new System.Windows.Forms.CheckBox();
            this.checkBoxNaranja = new System.Windows.Forms.CheckBox();
            this.checkBoxAzul = new System.Windows.Forms.CheckBox();
            this.checkBoxAmarillo = new System.Windows.Forms.CheckBox();
            this.checkBoxVerde = new System.Windows.Forms.CheckBox();
            this.checkBoxDiametro = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ltBxArre1);
            this.groupBox1.Controls.Add(this.btnImprimirArre1);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtBxCantidad1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.lblTotal1);
            this.groupBox1.Controls.Add(this.btnCalcularCosto1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtBxMaterial);
            this.groupBox1.Controls.Add(this.txtBxColor);
            this.groupBox1.Controls.Add(this.txtBxDiametro);
            this.groupBox1.Location = new System.Drawing.Point(12, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(408, 349);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PelotaForma1";
            // 
            // ltBxArre1
            // 
            this.ltBxArre1.FormattingEnabled = true;
            this.ltBxArre1.Location = new System.Drawing.Point(190, 87);
            this.ltBxArre1.Name = "ltBxArre1";
            this.ltBxArre1.Size = new System.Drawing.Size(198, 212);
            this.ltBxArre1.TabIndex = 12;
            // 
            // btnImprimirArre1
            // 
            this.btnImprimirArre1.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.btnImprimirArre1.Location = new System.Drawing.Point(228, 37);
            this.btnImprimirArre1.Name = "btnImprimirArre1";
            this.btnImprimirArre1.Size = new System.Drawing.Size(136, 44);
            this.btnImprimirArre1.TabIndex = 11;
            this.btnImprimirArre1.Text = "Imprimir Arreglo";
            this.btnImprimirArre1.UseVisualStyleBackColor = true;
            this.btnImprimirArre1.Click += new System.EventHandler(this.btnImprimirArre1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 198);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "Cantidad de pelotas";
            // 
            // txtBxCantidad1
            // 
            this.txtBxCantidad1.Location = new System.Drawing.Point(10, 214);
            this.txtBxCantidad1.Name = "txtBxCantidad1";
            this.txtBxCantidad1.Size = new System.Drawing.Size(158, 20);
            this.txtBxCantidad1.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(47, 310);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 18);
            this.label9.TabIndex = 8;
            this.label9.Text = "Total";
            // 
            // lblTotal1
            // 
            this.lblTotal1.AutoSize = true;
            this.lblTotal1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal1.Location = new System.Drawing.Point(100, 310);
            this.lblTotal1.Name = "lblTotal1";
            this.lblTotal1.Size = new System.Drawing.Size(29, 18);
            this.lblTotal1.TabIndex = 7;
            this.lblTotal1.Text = "0.0";
            // 
            // btnCalcularCosto1
            // 
            this.btnCalcularCosto1.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnCalcularCosto1.Location = new System.Drawing.Point(30, 254);
            this.btnCalcularCosto1.Name = "btnCalcularCosto1";
            this.btnCalcularCosto1.Size = new System.Drawing.Size(138, 40);
            this.btnCalcularCosto1.TabIndex = 6;
            this.btnCalcularCosto1.Text = "Calcular Costo";
            this.btnCalcularCosto1.UseVisualStyleBackColor = true;
            this.btnCalcularCosto1.Click += new System.EventHandler(this.btnCalcularCosto1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Material";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Color";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Diametro";
            // 
            // txtBxMaterial
            // 
            this.txtBxMaterial.Location = new System.Drawing.Point(10, 156);
            this.txtBxMaterial.Name = "txtBxMaterial";
            this.txtBxMaterial.Size = new System.Drawing.Size(158, 20);
            this.txtBxMaterial.TabIndex = 2;
            // 
            // txtBxColor
            // 
            this.txtBxColor.Location = new System.Drawing.Point(10, 98);
            this.txtBxColor.Name = "txtBxColor";
            this.txtBxColor.Size = new System.Drawing.Size(158, 20);
            this.txtBxColor.TabIndex = 1;
            // 
            // txtBxDiametro
            // 
            this.txtBxDiametro.Location = new System.Drawing.Point(10, 37);
            this.txtBxDiametro.Name = "txtBxDiametro";
            this.txtBxDiametro.Size = new System.Drawing.Size(158, 20);
            this.txtBxDiametro.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.tabControl1.Location = new System.Drawing.Point(426, 47);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(491, 390);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.cmbBxCantidad);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.lblTotal2);
            this.tabPage1.Controls.Add(this.btnCalcularCosto2);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.cmbBxMaterial);
            this.tabPage1.Controls.Add(this.cmbBxColor);
            this.tabPage1.Controls.Add(this.cmbBxDiametro);
            this.tabPage1.ForeColor = System.Drawing.Color.DarkMagenta;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(483, 364);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "PelotaForma2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 208);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Cantidad";
            // 
            // cmbBxCantidad
            // 
            this.cmbBxCantidad.FormattingEnabled = true;
            this.cmbBxCantidad.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cmbBxCantidad.Location = new System.Drawing.Point(22, 224);
            this.cmbBxCantidad.Name = "cmbBxCantidad";
            this.cmbBxCantidad.Size = new System.Drawing.Size(147, 21);
            this.cmbBxCantidad.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "Diametro";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(260, 217);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 18);
            this.label11.TabIndex = 11;
            this.label11.Text = "Total";
            // 
            // lblTotal2
            // 
            this.lblTotal2.AutoSize = true;
            this.lblTotal2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal2.Location = new System.Drawing.Point(313, 217);
            this.lblTotal2.Name = "lblTotal2";
            this.lblTotal2.Size = new System.Drawing.Size(29, 18);
            this.lblTotal2.TabIndex = 8;
            this.lblTotal2.Text = "0.0";
            // 
            // btnCalcularCosto2
            // 
            this.btnCalcularCosto2.Location = new System.Drawing.Point(289, 63);
            this.btnCalcularCosto2.Name = "btnCalcularCosto2";
            this.btnCalcularCosto2.Size = new System.Drawing.Size(100, 91);
            this.btnCalcularCosto2.TabIndex = 10;
            this.btnCalcularCosto2.Text = "Calcular Costo";
            this.btnCalcularCosto2.UseVisualStyleBackColor = true;
            this.btnCalcularCosto2.Click += new System.EventHandler(this.btnCalcularCosto2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Color";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Material";
            // 
            // cmbBxMaterial
            // 
            this.cmbBxMaterial.FormattingEnabled = true;
            this.cmbBxMaterial.Items.AddRange(new object[] {
            "Goma",
            "Plastico",
            "Piel"});
            this.cmbBxMaterial.Location = new System.Drawing.Point(17, 168);
            this.cmbBxMaterial.Name = "cmbBxMaterial";
            this.cmbBxMaterial.Size = new System.Drawing.Size(147, 21);
            this.cmbBxMaterial.TabIndex = 2;
            // 
            // cmbBxColor
            // 
            this.cmbBxColor.FormattingEnabled = true;
            this.cmbBxColor.Items.AddRange(new object[] {
            "Azul",
            "Amarillo",
            "Rojo"});
            this.cmbBxColor.Location = new System.Drawing.Point(17, 110);
            this.cmbBxColor.Name = "cmbBxColor";
            this.cmbBxColor.Size = new System.Drawing.Size(147, 21);
            this.cmbBxColor.TabIndex = 1;
            // 
            // cmbBxDiametro
            // 
            this.cmbBxDiametro.FormattingEnabled = true;
            this.cmbBxDiametro.Items.AddRange(new object[] {
            "7",
            "9",
            "12"});
            this.cmbBxDiametro.Location = new System.Drawing.Point(17, 57);
            this.cmbBxDiametro.Name = "cmbBxDiametro";
            this.cmbBxDiametro.Size = new System.Drawing.Size(147, 21);
            this.cmbBxDiametro.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.btnCalcularCosto3);
            this.tabPage2.Controls.Add(this.lblTotal3);
            this.tabPage2.Controls.Add(this.radioBtnPlastico);
            this.tabPage2.Controls.Add(this.radioBtnGoma);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.radioBtnLila);
            this.tabPage2.Controls.Add(this.radioBtnBlanco);
            this.tabPage2.Controls.Add(this.radioBtnAmarillo);
            this.tabPage2.Controls.Add(this.radioBtn3);
            this.tabPage2.Controls.Add(this.radioBtn2);
            this.tabPage2.Controls.Add(this.radioBtn1);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(483, 364);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "PelotaForma3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(141, 234);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 18);
            this.label10.TabIndex = 9;
            this.label10.Text = "Total";
            // 
            // btnCalcularCosto3
            // 
            this.btnCalcularCosto3.Location = new System.Drawing.Point(285, 198);
            this.btnCalcularCosto3.Name = "btnCalcularCosto3";
            this.btnCalcularCosto3.Size = new System.Drawing.Size(125, 54);
            this.btnCalcularCosto3.TabIndex = 20;
            this.btnCalcularCosto3.Text = "Calcular Costo";
            this.btnCalcularCosto3.UseVisualStyleBackColor = true;
            // 
            // lblTotal3
            // 
            this.lblTotal3.AutoSize = true;
            this.lblTotal3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal3.Location = new System.Drawing.Point(194, 232);
            this.lblTotal3.Name = "lblTotal3";
            this.lblTotal3.Size = new System.Drawing.Size(29, 18);
            this.lblTotal3.TabIndex = 19;
            this.lblTotal3.Text = "0.0";
            // 
            // radioBtnPlastico
            // 
            this.radioBtnPlastico.AutoSize = true;
            this.radioBtnPlastico.Location = new System.Drawing.Point(23, 251);
            this.radioBtnPlastico.Name = "radioBtnPlastico";
            this.radioBtnPlastico.Size = new System.Drawing.Size(62, 17);
            this.radioBtnPlastico.TabIndex = 18;
            this.radioBtnPlastico.TabStop = true;
            this.radioBtnPlastico.Text = "Plastico";
            this.radioBtnPlastico.UseVisualStyleBackColor = true;
            // 
            // radioBtnGoma
            // 
            this.radioBtnGoma.AutoSize = true;
            this.radioBtnGoma.Location = new System.Drawing.Point(23, 217);
            this.radioBtnGoma.Name = "radioBtnGoma";
            this.radioBtnGoma.Size = new System.Drawing.Size(53, 17);
            this.radioBtnGoma.TabIndex = 17;
            this.radioBtnGoma.TabStop = true;
            this.radioBtnGoma.Text = "Goma";
            this.radioBtnGoma.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 192);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Material";
            // 
            // radioBtnLila
            // 
            this.radioBtnLila.AutoSize = true;
            this.radioBtnLila.Location = new System.Drawing.Point(237, 135);
            this.radioBtnLila.Name = "radioBtnLila";
            this.radioBtnLila.Size = new System.Drawing.Size(41, 17);
            this.radioBtnLila.TabIndex = 15;
            this.radioBtnLila.TabStop = true;
            this.radioBtnLila.Text = "Lila";
            this.radioBtnLila.UseVisualStyleBackColor = true;
            // 
            // radioBtnBlanco
            // 
            this.radioBtnBlanco.AutoSize = true;
            this.radioBtnBlanco.Location = new System.Drawing.Point(237, 97);
            this.radioBtnBlanco.Name = "radioBtnBlanco";
            this.radioBtnBlanco.Size = new System.Drawing.Size(58, 17);
            this.radioBtnBlanco.TabIndex = 14;
            this.radioBtnBlanco.TabStop = true;
            this.radioBtnBlanco.Text = "Blanco";
            this.radioBtnBlanco.UseVisualStyleBackColor = true;
            // 
            // radioBtnAmarillo
            // 
            this.radioBtnAmarillo.AutoSize = true;
            this.radioBtnAmarillo.Location = new System.Drawing.Point(237, 60);
            this.radioBtnAmarillo.Name = "radioBtnAmarillo";
            this.radioBtnAmarillo.Size = new System.Drawing.Size(61, 17);
            this.radioBtnAmarillo.TabIndex = 13;
            this.radioBtnAmarillo.TabStop = true;
            this.radioBtnAmarillo.Text = "Amarillo";
            this.radioBtnAmarillo.UseVisualStyleBackColor = true;
            // 
            // radioBtn3
            // 
            this.radioBtn3.AutoSize = true;
            this.radioBtn3.Location = new System.Drawing.Point(35, 134);
            this.radioBtn3.Name = "radioBtn3";
            this.radioBtn3.Size = new System.Drawing.Size(98, 17);
            this.radioBtn3.TabIndex = 12;
            this.radioBtn3.TabStop = true;
            this.radioBtn3.Text = "3 pulgadas $15";
            this.radioBtn3.UseVisualStyleBackColor = true;
            // 
            // radioBtn2
            // 
            this.radioBtn2.AutoSize = true;
            this.radioBtn2.Location = new System.Drawing.Point(35, 97);
            this.radioBtn2.Name = "radioBtn2";
            this.radioBtn2.Size = new System.Drawing.Size(98, 17);
            this.radioBtn2.TabIndex = 11;
            this.radioBtn2.TabStop = true;
            this.radioBtn2.Text = "5 pulgadas $12";
            this.radioBtn2.UseVisualStyleBackColor = true;
            // 
            // radioBtn1
            // 
            this.radioBtn1.AutoSize = true;
            this.radioBtn1.Location = new System.Drawing.Point(35, 60);
            this.radioBtn1.Name = "radioBtn1";
            this.radioBtn1.Size = new System.Drawing.Size(92, 17);
            this.radioBtn1.TabIndex = 10;
            this.radioBtn1.TabStop = true;
            this.radioBtn1.Text = "7 pulgadas $9";
            this.radioBtn1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(234, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Color";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Diametro";
            // 
            // tabPage3
            // 
            this.tabPage3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage3.BackgroundImage")));
            this.tabPage3.Controls.Add(this.btnArreCheck);
            this.tabPage3.Controls.Add(this.litBxArreCheck);
            this.tabPage3.Controls.Add(this.numericUpDown1);
            this.tabPage3.Controls.Add(this.checkBox2);
            this.tabPage3.Controls.Add(this.checkBox1);
            this.tabPage3.Controls.Add(this.btnCostoCheckbox);
            this.tabPage3.Controls.Add(this.checkBoxPiel);
            this.tabPage3.Controls.Add(this.checkBoxGoma);
            this.tabPage3.Controls.Add(this.checkBoxPlastico);
            this.tabPage3.Controls.Add(this.checkBoxRojo);
            this.tabPage3.Controls.Add(this.checkBoxVioleta);
            this.tabPage3.Controls.Add(this.checkBoxNaranja);
            this.tabPage3.Controls.Add(this.checkBoxAzul);
            this.tabPage3.Controls.Add(this.checkBoxAmarillo);
            this.tabPage3.Controls.Add(this.checkBoxVerde);
            this.tabPage3.Controls.Add(this.checkBoxDiametro);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Cursor = System.Windows.Forms.Cursors.No;
            this.tabPage3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.ForeColor = System.Drawing.Color.PowderBlue;
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(483, 364);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Forma Checkbox";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnArreCheck
            // 
            this.btnArreCheck.Location = new System.Drawing.Point(279, 15);
            this.btnArreCheck.Name = "btnArreCheck";
            this.btnArreCheck.Size = new System.Drawing.Size(198, 43);
            this.btnArreCheck.TabIndex = 31;
            this.btnArreCheck.Text = "Imprimir Arreglo";
            this.btnArreCheck.UseVisualStyleBackColor = true;
            this.btnArreCheck.Click += new System.EventHandler(this.btnArreCheck_Click);
            // 
            // litBxArreCheck
            // 
            this.litBxArreCheck.DataSource = this.litBxArreCheck.CustomTabOffsets;
            this.litBxArreCheck.ForeColor = System.Drawing.Color.SandyBrown;
            this.litBxArreCheck.FormattingEnabled = true;
            this.litBxArreCheck.ItemHeight = 18;
            this.litBxArreCheck.Location = new System.Drawing.Point(279, 80);
            this.litBxArreCheck.Name = "litBxArreCheck";
            this.litBxArreCheck.Size = new System.Drawing.Size(198, 202);
            this.litBxArreCheck.TabIndex = 13;
            this.litBxArreCheck.SelectedIndexChanged += new System.EventHandler(this.litBxArreCheck_SelectedIndexChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(27, 281);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 25);
            this.numericUpDown1.TabIndex = 3;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.checkBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox2.Location = new System.Drawing.Point(27, 42);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(35, 22);
            this.checkBox2.TabIndex = 30;
            this.checkBox2.Text = "7";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.checkBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox1.Location = new System.Drawing.Point(68, 42);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(35, 22);
            this.checkBox1.TabIndex = 29;
            this.checkBox1.Text = "9";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // btnCostoCheckbox
            // 
            this.btnCostoCheckbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCostoCheckbox.Cursor = System.Windows.Forms.Cursors.No;
            this.btnCostoCheckbox.Location = new System.Drawing.Point(325, 288);
            this.btnCostoCheckbox.Name = "btnCostoCheckbox";
            this.btnCostoCheckbox.Size = new System.Drawing.Size(130, 54);
            this.btnCostoCheckbox.TabIndex = 28;
            this.btnCostoCheckbox.Text = "Calcular Costo";
            this.btnCostoCheckbox.UseVisualStyleBackColor = true;
            this.btnCostoCheckbox.Click += new System.EventHandler(this.btnCostoCheckbox_Click);
            // 
            // checkBoxPiel
            // 
            this.checkBoxPiel.AutoSize = true;
            this.checkBoxPiel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxPiel.Location = new System.Drawing.Point(193, 202);
            this.checkBoxPiel.Name = "checkBoxPiel";
            this.checkBoxPiel.Size = new System.Drawing.Size(57, 22);
            this.checkBoxPiel.TabIndex = 27;
            this.checkBoxPiel.Text = "Piel";
            this.checkBoxPiel.UseVisualStyleBackColor = true;
            // 
            // checkBoxGoma
            // 
            this.checkBoxGoma.AutoSize = true;
            this.checkBoxGoma.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxGoma.Location = new System.Drawing.Point(111, 202);
            this.checkBoxGoma.Name = "checkBoxGoma";
            this.checkBoxGoma.Size = new System.Drawing.Size(68, 22);
            this.checkBoxGoma.TabIndex = 26;
            this.checkBoxGoma.Text = "Goma";
            this.checkBoxGoma.UseVisualStyleBackColor = true;
            // 
            // checkBoxPlastico
            // 
            this.checkBoxPlastico.AutoSize = true;
            this.checkBoxPlastico.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxPlastico.Location = new System.Drawing.Point(19, 202);
            this.checkBoxPlastico.Name = "checkBoxPlastico";
            this.checkBoxPlastico.Size = new System.Drawing.Size(86, 22);
            this.checkBoxPlastico.TabIndex = 25;
            this.checkBoxPlastico.Text = "Plastico";
            this.checkBoxPlastico.UseVisualStyleBackColor = true;
            // 
            // checkBoxRojo
            // 
            this.checkBoxRojo.AutoSize = true;
            this.checkBoxRojo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxRojo.Location = new System.Drawing.Point(194, 129);
            this.checkBoxRojo.Name = "checkBoxRojo";
            this.checkBoxRojo.Size = new System.Drawing.Size(61, 22);
            this.checkBoxRojo.TabIndex = 24;
            this.checkBoxRojo.Text = "Rojo";
            this.checkBoxRojo.UseVisualStyleBackColor = true;
            // 
            // checkBoxVioleta
            // 
            this.checkBoxVioleta.AutoSize = true;
            this.checkBoxVioleta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxVioleta.Location = new System.Drawing.Point(107, 134);
            this.checkBoxVioleta.Name = "checkBoxVioleta";
            this.checkBoxVioleta.Size = new System.Drawing.Size(80, 22);
            this.checkBoxVioleta.TabIndex = 23;
            this.checkBoxVioleta.Text = "Violeta";
            this.checkBoxVioleta.UseVisualStyleBackColor = true;
            // 
            // checkBoxNaranja
            // 
            this.checkBoxNaranja.AutoSize = true;
            this.checkBoxNaranja.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxNaranja.Location = new System.Drawing.Point(19, 134);
            this.checkBoxNaranja.Name = "checkBoxNaranja";
            this.checkBoxNaranja.Size = new System.Drawing.Size(86, 22);
            this.checkBoxNaranja.TabIndex = 22;
            this.checkBoxNaranja.Text = "Naranja";
            this.checkBoxNaranja.UseVisualStyleBackColor = true;
            // 
            // checkBoxAzul
            // 
            this.checkBoxAzul.AutoSize = true;
            this.checkBoxAzul.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxAzul.Location = new System.Drawing.Point(193, 101);
            this.checkBoxAzul.Name = "checkBoxAzul";
            this.checkBoxAzul.Size = new System.Drawing.Size(62, 22);
            this.checkBoxAzul.TabIndex = 21;
            this.checkBoxAzul.Text = "Azul";
            this.checkBoxAzul.UseVisualStyleBackColor = true;
            // 
            // checkBoxAmarillo
            // 
            this.checkBoxAmarillo.AutoSize = true;
            this.checkBoxAmarillo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxAmarillo.Location = new System.Drawing.Point(94, 101);
            this.checkBoxAmarillo.Name = "checkBoxAmarillo";
            this.checkBoxAmarillo.Size = new System.Drawing.Size(93, 22);
            this.checkBoxAmarillo.TabIndex = 20;
            this.checkBoxAmarillo.Text = "Amarillo";
            this.checkBoxAmarillo.UseVisualStyleBackColor = true;
            // 
            // checkBoxVerde
            // 
            this.checkBoxVerde.AutoSize = true;
            this.checkBoxVerde.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxVerde.Location = new System.Drawing.Point(19, 101);
            this.checkBoxVerde.Name = "checkBoxVerde";
            this.checkBoxVerde.Size = new System.Drawing.Size(69, 22);
            this.checkBoxVerde.TabIndex = 19;
            this.checkBoxVerde.Text = "Verde";
            this.checkBoxVerde.UseVisualStyleBackColor = true;
            // 
            // checkBoxDiametro
            // 
            this.checkBoxDiametro.AutoSize = true;
            this.checkBoxDiametro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.checkBoxDiametro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxDiametro.Location = new System.Drawing.Point(109, 42);
            this.checkBoxDiametro.Name = "checkBoxDiametro";
            this.checkBoxDiametro.Size = new System.Drawing.Size(43, 22);
            this.checkBoxDiametro.TabIndex = 2;
            this.checkBoxDiametro.Text = "12";
            this.checkBoxDiametro.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.LightCoral;
            this.label15.Location = new System.Drawing.Point(18, 254);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 18);
            this.label15.TabIndex = 18;
            this.label15.Text = "Cantidad";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.LightCoral;
            this.label16.Location = new System.Drawing.Point(16, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 18);
            this.label16.TabIndex = 17;
            this.label16.Text = "Diametro";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.LightCoral;
            this.label17.Location = new System.Drawing.Point(16, 68);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 18);
            this.label17.TabIndex = 15;
            this.label17.Text = "Color";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.LightCoral;
            this.label18.Location = new System.Drawing.Point(18, 171);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 18);
            this.label18.TabIndex = 16;
            this.label18.Text = "Material";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Consolas", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(234, 9);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(510, 32);
            this.label20.TabIndex = 2;
            this.label20.Text = "Tu Pelota Personalizada Solo Aqui";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(921, 476);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.LawnGreen;
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblTotal1;
        private System.Windows.Forms.Button btnCalcularCosto1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBxMaterial;
        private System.Windows.Forms.TextBox txtBxColor;
        private System.Windows.Forms.TextBox txtBxDiametro;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblTotal2;
        private System.Windows.Forms.Button btnCalcularCosto2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbBxMaterial;
        private System.Windows.Forms.ComboBox cmbBxColor;
        private System.Windows.Forms.ComboBox cmbBxDiametro;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnCalcularCosto3;
        private System.Windows.Forms.Label lblTotal3;
        private System.Windows.Forms.RadioButton radioBtnPlastico;
        private System.Windows.Forms.RadioButton radioBtnGoma;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton radioBtnLila;
        private System.Windows.Forms.RadioButton radioBtnBlanco;
        private System.Windows.Forms.RadioButton radioBtnAmarillo;
        private System.Windows.Forms.RadioButton radioBtn3;
        private System.Windows.Forms.RadioButton radioBtn2;
        private System.Windows.Forms.RadioButton radioBtn1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtBxCantidad1;
        private System.Windows.Forms.ListBox ltBxArre1;
        private System.Windows.Forms.Button btnImprimirArre1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbBxCantidad;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.CheckBox checkBoxPiel;
        private System.Windows.Forms.CheckBox checkBoxGoma;
        private System.Windows.Forms.CheckBox checkBoxPlastico;
        private System.Windows.Forms.CheckBox checkBoxRojo;
        private System.Windows.Forms.CheckBox checkBoxVioleta;
        private System.Windows.Forms.CheckBox checkBoxNaranja;
        private System.Windows.Forms.CheckBox checkBoxAzul;
        private System.Windows.Forms.CheckBox checkBoxAmarillo;
        private System.Windows.Forms.CheckBox checkBoxVerde;
        private System.Windows.Forms.CheckBox checkBoxDiametro;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnCostoCheckbox;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button btnArreCheck;
        private System.Windows.Forms.ListBox litBxArreCheck;
    }
}

