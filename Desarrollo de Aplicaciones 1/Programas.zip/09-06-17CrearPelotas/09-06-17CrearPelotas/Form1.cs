﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _09_06_17CrearPelotas
{
    public partial class Form1 : Form
    {
        Costo c1 = new Costo();
        Checkabox ch1=new Checkabox();
        int indice=0;
        double [] arre2 = new double[10];
        double[] arre3 = new double[10];
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcularCosto1_Click(object sender, EventArgs e)
        {
            double totaal = 0;
            if (indice <= 9)
            {
                int diametr = Convert.ToInt32(txtBxDiametro.Text);
                //string colo = txtBxColor.Text;
                string materia = txtBxMaterial.Text;
                int cantida = Convert.ToInt32(txtBxCantidad1.Text);
                c1.Calcular_Costo1(diametr, materia, cantida, ref totaal);
                lblTotal1.Text = totaal.ToString();
                arre3[indice] = totaal;                
                indice++;
            }
        }

        private void btnCalcularCosto2_Click(object sender, EventArgs e)
        {
            
            double totaal = 0;
            if (indice <= 9)
            {
                int diame = Convert.ToInt32(cmbBxDiametro.SelectedIndex.ToString());
                string materia = cmbBxColor.SelectedIndex.ToString();
                int cantida = Convert.ToInt32(cmbBxCantidad.SelectedIndex.ToString());
                string materiaal =Convert.ToString(cmbBxMaterial.Text);
                c1.Calcular_Costo1(diame, materia, cantida, ref totaal);
                lblTotal2.Text = totaal.ToString();
                arre3[indice] = totaal;
                indice++;
            }
        }

        private void btnImprimirArre1_Click(object sender, EventArgs e)
        {
            for (int y = 0; y <= 1; y++)
            {
                ltBxArre1.Items.Add(arre2[y]);
            }
        }

        private void btnCostoCheckbox_Click(object sender, EventArgs e)
        {

            if (checkBoxDiametro.Checked == true && checkBoxVerde.Checked == true && checkBoxPlastico.Checked == true)
            {
                if (indice <= 9)
                {
                    double total = 0;
                    int dia = Convert.ToInt32(checkBoxDiametro.Checked);
                    double colo = Convert.ToDouble(checkBoxVerde.Checked);
                    int materia = Convert.ToInt32(checkBoxPlastico.Checked);
                    int cantida = Convert.ToInt32(numericUpDown1.Value);
                    ch1.Calcular_check1(dia, colo, materia, cantida, ref total);
                    MessageBox.Show("El Costo Total es: " + total);
                    arre3[indice] = total;
                    indice++;
                }

            }
            else if (checkBoxDiametro.Checked == true && checkBoxAmarillo.Checked == true && checkBoxPlastico.Checked == true)
            {
                if (indice <= 9)
                {
                double total = 0;
                int dia = Convert.ToInt32(checkBoxDiametro.Checked);
                double colo = Convert.ToDouble(checkBoxAmarillo.Checked);
                int materia = Convert.ToInt32(checkBoxPlastico.Checked);
                int cantida = Convert.ToInt32(numericUpDown1.Value);
                ch1.Calcular_check2(dia, colo, materia, cantida, ref total);
                MessageBox.Show("El Costo Total es: " + total);
                arre3[indice] = total;
                indice++;
                }
            }
            else if (checkBoxDiametro.Checked == true && checkBoxAzul.Checked == true && checkBoxPlastico.Checked== true)
            {
                if (indice <= 9)
                {
                double total = 0;
                int dia = Convert.ToInt32(checkBoxDiametro.Checked);
                double colo = Convert.ToDouble(checkBoxAzul.Checked);
                int materia = Convert.ToInt32(checkBoxPlastico.Checked);
                int cantida = Convert.ToInt32(numericUpDown1.Value);
                ch1.Calcular_check3(dia, colo, materia, cantida, ref total);
                MessageBox.Show("El Costo Total es: " + total);
                arre3[indice] = total;
                    indice++;
                }
            }
            else if (checkBoxDiametro.Checked == true && checkBoxNaranja.Checked == true && checkBoxGoma.Checked == true)
            {
                if (indice <= 9)
                {
                double total = 0;
                int dia = Convert.ToInt32(checkBoxDiametro.Checked);
                double colo = Convert.ToDouble(checkBoxNaranja.Checked);
                int materia = Convert.ToInt32(checkBoxGoma.Checked);
                int cantida = Convert.ToInt32(numericUpDown1.Value);
                ch1.Calcular_check4(dia, colo, materia, cantida, ref total);
                MessageBox.Show("El Costo Total es: " + total);
                    arre3[indice] = total;
                    indice++;
                }
            }
            else if (checkBoxDiametro.Checked == true && checkBoxVioleta.Checked == true && checkBoxGoma.Checked == true)
            {
                if (indice <= 9)
                {
                double total = 0;
                int dia = Convert.ToInt32(checkBoxDiametro.Checked);
                double colo = Convert.ToDouble(checkBoxVioleta.Checked);
                int materia = Convert.ToInt32(checkBoxGoma.Checked);
                int cantida = Convert.ToInt32(numericUpDown1.Value);
                ch1.Calcular_check5(dia, colo, materia, cantida, ref total);
                MessageBox.Show("El Costo Total es: " + total);
                    arre3[indice] = total;
                    indice++;
                }
            }
            else if (checkBoxDiametro.Checked == true && checkBoxRojo.Checked == true && checkBoxGoma.Checked == true)
            {
                if (indice <= 9)
                {
                double total = 0;
                int dia = Convert.ToInt32(checkBoxDiametro.Checked);
                double colo = Convert.ToDouble(checkBoxRojo.Checked);
                int materia = Convert.ToInt32(checkBoxGoma.Checked);
                int cantida = Convert.ToInt32(numericUpDown1.Value);
                ch1.Calcular_check6(dia, colo, materia, cantida, ref total);
                MessageBox.Show("El Costo Total es: " + total);
                arre3[indice] = total;
                indice++;
                }
            }
            else if (checkBoxDiametro.Checked == true && checkBoxVerde.Checked == true && checkBoxPiel.Checked == true)
            {
                if (indice <= 9)
                {
                    double total = 0;
                    int dia = Convert.ToInt32(checkBoxDiametro.Checked);
                    double colo = Convert.ToDouble(checkBoxVerde.Checked);
                    int materia = Convert.ToInt32(checkBoxPiel.Checked);
                    int cantida = Convert.ToInt32(numericUpDown1.Value);
                    ch1.Calcular_check7(dia, colo, materia, cantida, ref total);
                    MessageBox.Show("El Costo Total es: " + total);
                    arre2[indice] = total;
                    indice++;
                }
            }
            else if (checkBoxDiametro.Checked == true && checkBoxAmarillo.Checked == true && checkBoxPiel.Checked == true)
            {
                if (indice <= 9)
                {
                    double total = 0;
                    int dia = Convert.ToInt32(checkBoxDiametro.Checked);
                    double colo = Convert.ToDouble(checkBoxAmarillo.Checked);
                    int materia = Convert.ToInt32(checkBoxPiel.Checked);
                    int cantida = Convert.ToInt32(numericUpDown1.Value);
                    ch1.Calcular_check8(dia, colo, materia, cantida, ref total);
                    MessageBox.Show("El Costo Total es: " + total);
                    arre3[indice] = total;
                    indice++;
                }
            }
            else if (checkBoxDiametro.Checked == true && checkBoxAzul.Checked == true && checkBoxPiel.Checked == true)
            {
                if (indice <= 9)
                {
                    double total = 0;
                    int dia = Convert.ToInt32(checkBoxDiametro.Checked);
                    double colo = Convert.ToDouble(checkBoxAzul.Checked);
                    int materia = Convert.ToInt32(checkBoxPiel.Checked);
                    int cantida = Convert.ToInt32(numericUpDown1.Value);
                    ch1.Calcular_check9(dia, colo, materia, cantida, ref total);
                    MessageBox.Show("El Costo Total es: " + total);
                    arre3[indice] = total;
                    indice++;
                }
            }
        
          }

        private void btnArreCheck_Click(object sender, EventArgs e)
        {

            for (int j = 0; j <= 9; j++)
            {
                double suma = 0;
                suma = suma + arre3[indice];
                // litBxArreCheck.Items.Add();
                litBxArreCheck.Items.Add(arre3[j].ToString());
            }
            litBxArreCheck.Items.Add("el total es: " + total); 

        }

        private void litBxArreCheck_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        }
    }
