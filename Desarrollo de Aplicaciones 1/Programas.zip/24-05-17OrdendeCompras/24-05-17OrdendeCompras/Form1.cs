﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _24_05_17OrdendeCompras
{
    public partial class Form1 : Form
    {
        Cliente cl = new Cliente();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            string Meensaje="";
            cl.insertar(ref Meensaje, Convert.ToInt32(txtBxIDCliente.Text), txtBxNombre.Text, txtBxDirecc.Text, txtBxCodigoP.Text);
        }
    }
}
