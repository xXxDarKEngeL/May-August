﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _24_05_17OrdendeCompras
{
    class Cliente
    {
        public string ServidorSQL { set; get; }
        public string BD { set; get; }

        public void insertar(ref string mensaje, int IDCliente, string Nombre, string Direccion, string CodigoPostal)
        {
            SqlConnection carrier=new SqlConnection(@"data source=PC14"+ " ;Initial Catalog=OrdenCompras " + " ;Integrated Security=true;");
            SqlCommand Carre = new SqlCommand();
            try
            {
                carrier.Open();
                mensaje = "Conexion exitosa";
                Carre.CommandText = "insert into Cliente (IDCliente, Nombre, Direccion, CodigoPostalantidad) values ('"+IDCliente+"''" + Nombre + "', '" + Direccion + "', '" + CodigoPostal + "')";
                Carre.Connection = carrier;
                Carre.ExecuteNonQuery();
                MessageBox.Show("Cliente Creado");
                carrier.Close();
            }
            catch(Exception ey)
            {
                carrier = null;
                mensaje = "error" + ey.Message;
            }
        }
    }
}
